import json
import time
import Consonants as constant
import pytz
import datetime
from datetime import timedelta
from pytz import timezone
from pandas import json_normalize
import requests
# import pyarrow
import boto3
from dateutil.tz import tzutc, UTC
import pandas as pd
from pandas import DataFrame
import numpy as np
from io import BytesIO
from io import StringIO
from json import dumps
from pandas.io.json import json_normalize
#from datetime import datetime as dt
bucket = 'apioutput' # already created on S3
client = boto3.client('ssm')
sns = boto3.client("sns", region_name="eu-north-1")
ssm = boto3.client("ssm", region_name="eu-north-1")
s3_resource = boto3.resource('s3')
url = ssm.get_parameter(Name=constant.urlapi, WithDecryption=True)["Parameter"]["Value"]
#url = "https://results.us.securityeducation.com/api/reporting/v0.1.0/phishing"
my_headers = {'x-apikey-token' : 'YV5iYWWji13z25LX/ZAQOwmHKmHqdpQk8pQzIcSQ5hGl3cpog'}
s3_prefix = "result/csvfiles"
def get_datetime():
    dt = datetime.datetime.now()
    return dt.strftime("%Y%m%d"), dt.strftime("%H:%M:%S")
datestr, timestr = get_datetime()
fname = f"data_api_tripler_{datestr}_{timestr}.csv"
file_prefix = "/".join([s3_prefix, fname])
# print(file_prefix)

def send_sns_success():
    success_sns_arn = ssm.get_parameter(Name=constant.SUCCESSNOTIFICATIONARN, WithDecryption=True)["Parameter"]["Value"]
    component_name = constant.COMPONENT_NAME
    env = ssm.get_parameter(Name=constant.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    success_msg = constant.SUCCESS_MSG
    sns_message = (f"{component_name} :  {success_msg}")
    print(sns_message, 'text')
    succ_response = sns.publish(TargetArn=success_sns_arn,Message=json.dumps({'default': json.dumps(sns_message)}),
        Subject= env + " : " + component_name,MessageStructure="json")
    return succ_response
    
def send_error_sns():
   
    error_sns_arn = ssm.get_parameter(Name=constant.ERRORNOTIFICATIONARN)["Parameter"]["Value"]
    env = ssm.get_parameter(Name=constant.ENVIRONMENT, WithDecryption=True)['Parameter']['Value']
    error_message=constant.ERROR_MSG
    component_name = constant.COMPONENT_NAME
    sns_message = (f"{component_name} : {error_message}")
    err_response = sns.publish(TargetArn=error_sns_arn,Message=json.dumps({'default': json.dumps(sns_message)}),    Subject=env + " : " + component_name,
        MessageStructure="json")
    return err_response



    
    
def lambda_handler(event, context):
    try:
        r = requests.get(url, headers=my_headers)
        while r.status_code == 404:
            print("The URL is not hit")
            time.sleep(300)
        if r.status_code != 404:
            print("the URl is HIT ")
        d = r.json()
        df = pd.DataFrame(d['data'])
        # print(df)
        df1 = df[df.columns.drop(['attributes'])]
        a = [d.values() for d in df.attributes]
        b = [d.keys() for d in df.attributes]
        x = b.pop(0)
        df2 = pd.DataFrame(a, columns=x)
        result = pd.concat([df1, df2], axis=1, join="outer")
        result.index = range(1, len(result) + 1)
        month = datetime.datetime.now().strftime("%m")
        date = datetime.datetime.now().strftime("%I")
        day = datetime.datetime.now().strftime("%A")
        result['current_date'] = time
        result["month"] = pd.Series([month] * len(result))
        result["date"] = pd.Series([date] * len(result))
        result["day"] = pd.Series([day] * len(result))
        a = ['userfirstname', 'userlastname', 'sso_id', 'useremailaddress', 'month', 'date', 'day', 'current_date']
        b = result[a]
        b['status'] = 'False'
        repeated_values = b[b['sso_id'].duplicated(keep=False)]
        b.loc[b['sso_id'].isin(repeated_values['sso_id']), 'status'] = 'True'
        b['count'] = b.groupby('sso_id')['sso_id'].transform('count')
        b[['username', 'domain']] = b['useremailaddress'].str.extract(r'(.*)@(.*)')
        usernames = b['username']
        domains = b['domain']
        print(b.columns)
        print(len(b.columns))
        #writing the files without partition
        csv_buffer1 = StringIO()
        b.to_csv(csv_buffer1)
        # Writing the Files to CSV 
        s3_resource.Object(bucket, file_prefix).put(Body=csv_buffer1.getvalue())
        print('CSV files written')
        send_sns_success()
        print("The Success mail has been triggered")
    
    except Exception as e:
        print(e)
        send_error_sns()
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }